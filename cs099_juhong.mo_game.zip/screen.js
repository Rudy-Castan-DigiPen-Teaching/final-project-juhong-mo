class MainMenu {

  constructor() {

    const center_x = width / 2;
    this.play = new Button(center_x, height * 2 / 5, "Game Start");
    this.options = new Button(center_x, height * 5 / 10 + 20, "Option");
    this.credits = new Button(center_x, height * 6 / 10 + 40, "How To Play");

  }

  update() {

    if (this.play.DidClickButton()) {
      stage += 1;
      CurrentScene = GAME;
    } else if (this.options.DidClickButton()) {
      CurrentScene = OPTIONS_SCREEN;
    } else if (this.credits.DidClickButton()) {
      CurrentScene = CREDITS_SCREEN;
    }

  }

  draw() {

    DrawTitle("🏃‍Running Rectengle🏃‍");
    this.play.DrawButton();
    this.options.DrawButton();
    this.credits.DrawButton();
    push();
    textAlign(CENTER);
    fill(0);
    noStroke();
    textSize(20);
    text("Change the player's color at option!", width / 2, height - 150);
    pop();

  }

}

class CreditsScreen {

  constructor() {

    this.back = new Button(width / 2, height - 150, "Back");

  }

  update() {

    if (this.back.DidClickButton()) {
      CurrentScene = MAIN_MENU;
    }

  }

  draw() {

    DrawTitle("How to Play");

    push();
    textAlign(CENTER);
    textSize(25);
    text("The Rectangle moves automatically\nRun & Stop : Space        \n\n\n\n\n\n\nMade by Juhong Mo", width / 2, height / 2 - 50);

    this.back.DrawButton();

  }

}

class OptionsScreen {

  constructor() {

    const center_x = width / 2;
    this.sound = new Button(center_x, height / 2 - 100, "Sound");
    this.color = new Button(center_x, height / 2 + 75, "Color");
    this.back = new Button(center_x, height - 150, "Back");

  }

  update() {

    if (this.sound.DidClickButton()) {
      BGM.stop();
      bgm += 1;
      if (bgm % 2 == 1) {
        BGM.loop();
      }
    } else if (this.color.DidClickButton()) {
      playercolor = color(random(180, 255), random(120, 230), random(180, 255));
    } else if (this.back.DidClickButton()) {
      CurrentScene = MAIN_MENU;
    }

  }

  draw() {

    DrawTitle("Option");
    this.sound.DrawButton();
    this.color.DrawButton();
    this.back.DrawButton();
    push();
    stroke(255);
    strokeWeight(2);
    fill(playercolor);
    circle(width / 2, height / 2 + 230, 80);
    pop();

  }

}

class GameOverScreen {

  constructor() {
    this.y = 680;
    this.again = new Button(400, this.y, "Try Again");
    this.main = new Button(800, this.y, "Main Menu");
  }

  update() {

    if (this.again.DidClickButton()) {
      CurrentScene = GAME;
    } else if (this.main.DidClickButton()) {
      CurrentScene = MAIN_MENU;
    }

  }

  draw() {

    push();
    textAlign(CENTER);
    fill(255, 0, 0);
    stroke(255, 0, 0);
    strokeWeight(2);
    textSize(50);
    text("Game Over!", width / 2, height / 2 - 50);
    stroke(255, 160);
    strokeWeight(5);
    text("Game Over!", width / 2, height / 2 - 50);

    
    strokeWeight(3);
    textSize(20);
    fill(255);
    stroke(255);
    text("Press F5 if you want to play again", width / 2, height / 2 + 50);strokeWeight(1);
    textSize(20);
    fill(0);
    stroke(0);
    text("Press F5 if you want to play again", width / 2, height / 2 + 50);
    pop();

  }

}