class Life {

  constructor() {

    const Y = 700;
    this.x = 50;
    this.y = 1120;
    this.p = new Player();
    this.lex = -15;
    this.rex = 15;
    this.ey = -10;
    this.le = random(-20, 5);
    this.re = random(5, 20);
    this.by = random(-5, -20);
    this.a = 0;
    this.b = 0;

  }

  update() {

    this.p.update();
    this.a += 0.05;
    this.b -= 0.05;

  }

  heart1() {

    push();
    translate(this.x, this.y);
    imageMode(CENTER);
    image(HEART, 30, -20, 45, 40);
    pop();

  }

  heart2() {

    push();
    translate(this.x, this.y);
    imageMode(CENTER);
    image(HEART, 100, -20, 45, 40);
    pop();

  }

  heart3() {

    push();
    translate(this.x, this.y);
    imageMode(CENTER);
    image(HEART, 170, -20, 45, 40);
    pop();

  }

  eyes() {

    push();
    angleMode(DEGREES);
    translate(this.p.x, this.p.y);
    stroke(0);
    strokeWeight(2);
    fill(255);
    if (this.p.side % 4 == 3) {
      rotate(-90);
      circle(this.lex, this.ey, 25);
      circle(this.rex, this.ey, 25);
    }

    if (this.p.side % 4 == 0) {
      rotate(-180);
      circle(this.lex, this.ey, 25);
      circle(this.rex, this.ey, 25);
    }

    if (this.p.side % 4 == 1) {
      rotate(90);
      circle(this.lex, this.ey, 25);
      circle(this.rex, this.ey, 25);
    }

    if (this.p.side % 4 == 2) {
      circle(this.lex, this.ey, 25);
      circle(this.rex, this.ey, 25);
    }

  }

  googly() {

    angleMode(RADIANS);
    noStroke();
    fill(0);
    push();
    translate(this.lex, this.ey);
    rotate(this.a);
    circle(-3, -3, 12);
    pop();
    push();
    translate(this.rex, this.ey);
    rotate(this.b);
    circle(3, -3, 12);
    pop();
    pop();

  }

}

class Score {

  constructor() {

    this.x = 1120;
    this.y = 1120;

  }

  update() {

    Chance();

  }

  draw() {

    push();
    fill(0);
    textAlign(RIGHT);
    textSize(40);
    text("score : " + score, this.x, this.y);
    pop();

  }

  over() {

    push();
    textAlign(CENTER);
    textSize(35);
    fill(255);
    stroke(255);
    strokeWeight(5);
    text("score : " + score, width / 2, height / 2 - 10);
    fill(0);
    stroke(0);
    strokeWeight(1);
    text("score : " + score, width / 2, height / 2 - 10);
    pop();

  }

}

function Chance() {

  if (chance >= 1) {
    life.heart1();
    showscore.draw();
    if (chance >= 2) {
      life.heart2();
      if (chance >= 3) {
        life.heart3();
      }
    }
  }

}

function getScore() {

  score += a;
  if (chance < 1) {
    a = 0;
  }

}