class Balls {

  constructor(x, y, speed, direction) {

    this.bx = new Vec2(x, y);
    this.by = new Vec2(0, 0);
    this.bs = 15;
    this.by.setLength(speed);
    this.by.setAngle(direction);

    this.rx = new Vec2(x, y);
    this.ry = new Vec2(0, 0);
    this.rs = 20;
    this.ry.setLength(speed);
    this.ry.setAngle(direction);

    this.player = new Player();
  
  }

  update() {

    this.player.update();
    angleMode(RADIANS);

    if (this.bx.x + this.bs >= this.player.x - this.player.size / 2 && this.bx.x - this.bs <= this.player.x + this.player.size / 2 && this.bx.y + this.bs / 2 >= this.player.y - this.player.size / 2 && this.bx.y - this.bs / 2 <= this.player.y + this.player.size / 2) {

      chance -= 1;

    }

    if (this.rx.x >= this.player.x - this.player.size / 2 && this.rx.x <= this.player.x + this.player.size / 2 && this.rx.y + this.rs / 2 >= this.player.y - this.player.size / 2 && this.rx.y - this.rs / 2 <= this.player.y + this.player.size / 2) {

      chance -= 1;

    }


    this.bx.addTo(this.by);
    this.rx.addTo(this.ry);

  }

  attackblack() {

    noStroke();
    ellipseMode(CENTER);
    fill(0, 220);
    circle(this.bx.x, this.bx.y, this.bs * 2);

  }

  attackred() {
    
    noStroke();
    ellipseMode(CENTER);
    fill(255, 0, 0, 220);
    circle(this.rx.x, this.rx.y, this.rs * 2);

  }

}

function Black() {

  for (var i = 0; i < 1; i++) {

    balls1.push(new Balls(width / 2, height / 2 - 50, random() * 5 + 1, random() * PI * 2));

  }

}

function Red() {

  for (var i = 0; i < 1; i++) {

    balls2.push(new Balls(width / 2, height / 2 - 50, random() * 2 + 1, random() * PI * 2));

  }

}

function Drawballs() {

  for (let i = 0; i < balls1.length; i++) {

    balls1[i].update();
    balls1[i].attackblack();
    if (chance < 1)
      noLoop();

  }

  if (balls1.length > 50) {

    balls1.splice(0, 1);

  }

  for (let i = 0; i < balls2.length; i++) {

    balls2[i].update();
    balls2[i].attackred();

    if (chance < 1)
      noLoop();

  }

  if (balls2.length > 3) {

    balls2.splice(0, 1);

  }

}