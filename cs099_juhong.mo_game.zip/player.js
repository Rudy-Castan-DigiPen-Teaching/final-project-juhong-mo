class Player {

  constructor() {

    this.x = 80;
    this.y = 1020;
    this.size = 25;
    
    this.newcolor = new OptionsScreen();

    this.Xspeed = 5;
    this.Yspeed = 0;
    this.side = 2;

  }

  update() {
    
    this.r = this.newcolor.r;
    this.g = this.newcolor.g;
    this.b = this.newcolor.b;

    if (move % 2 == 1) {
      this.Xspeed = 0;
      this.Yspeed = 0;
    } else if (move % 2 == 0) {

      this.x += this.Xspeed;
      this.y += this.Yspeed;

      if (this.x == 1120 && this.y == 1020) {
        this.side += 1;
        this.Xspeed = 0;
        this.Yspeed = -5;
      }

      if (this.x == 1120 && this.y == 80) {
        this.side += 1;
        this.Xspeed = -5;
        this.Yspeed = 0;
      }

      if (this.x == 80 && this.y == 80) {
        this.side += 1;
        this.Xspeed = 0;
        this.Yspeed = 5
      }

      if (this.x == 80 && this.y == 1020) {
        this.side += 1;
        this.Xspeed = 5;
        this.Yspeed = 0;
      }
      
      if (this.side % 4 == 2) {
        this.Xspeed = 5;
        this.Yspeed = 0;
      } else if (this.side % 4 == 3) {
        this.Xspeed = 0;
        this.Yspeed = -5;
      } else if (this.side % 4 == 0) {
        this.Xspeed = -5;
        this.Yspeed = 0;
      } else if (this.side % 4 == 1) {
        this.Xspeed = 0;
        this.Yspeed = 5;
      }
    }

  }

  run() {

    push();
    noStroke();
    rectMode(CENTER);
    fill(playercolor);
    rect(this.x, this.y, this.size * 2, this.size * 2);
    pop();

  }

}

function keyPressed() {

  if (keyCode == '32') {

    move += 1;

  }

}