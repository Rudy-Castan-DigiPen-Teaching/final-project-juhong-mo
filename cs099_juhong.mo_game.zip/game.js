// Final Project
// Juhong Mo 모주홍
// cs099
// Spring 2020

function GameScreen() {

  noStroke();

  push();
  rectMode(CENTER);
  strokeWeight(8);
  strokeJoin(ROUND);
  stroke('Plum');
  fill(255);
  rect(width / 2, height / 2 - 50, width - 100, height - 200);
  pop();

}

class Game {

  constructor() {

    this.p = new Player();
    this.l = new Life();

  }

  update() {

    this.p.update();
    this.l.update();

  }

  draw() {

    GameScreen();

    this.p.run();
    this.l.eyes();
    this.l.googly();

    Drawballs();
    
    push();
    rectMode(CORNER);
    noStroke();
    fill('Pink');
    rect(0, 0, 46, height);
    rect(0, 1054, width, 180);
    rect(1154, 0, 46, height);
    rect(0, 0, width, 46);
    pop();

    Chance();

    if (chance < 1)
      Game_Over();

  }

}

function Game_Over() {

  showscore.over();
  GameoverScene.update();
  GameoverScene.draw();

}