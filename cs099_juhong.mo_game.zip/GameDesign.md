GameDesign

This game is made by referring to the 'nom3', Korean game. The character moves automatically for only one direction. If player press space on keyboard, the character would stop or go. Obstacles come from the center of the game screen.
There are Black balls and Red balls and player have to avoid them. If player crash to them, he will lose the life.
Player can see his life at left side of bottom and his score at right side of bottom. But when player has no more life, score would come center of the game screen with the text, 'Game over'.
Default of the character's color is gray(150), but it could be change at the option screen if player want to change it. Also, player can turn on or off the Background Music.
At 'How to Play', player can see the control key and credit.