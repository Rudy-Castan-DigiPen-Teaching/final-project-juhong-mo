// Final Project
// Juhong Mo 모주홍
// cs099
// Spring 2020

const MAIN_MENU = 1;
const CREDITS_SCREEN = 2;
const OPTIONS_SCREEN = 3;
const GAME = 4;
const GAME_OVER = 5;

let CurrentScene = MAIN_MENU;

let MainScene;
let CreditsScene;
let OptionsScene;
let GameScene;
let GameoverScene;

var HEART;
var bgm = 1;
var BGM;

var balls1 = [];
var balls2 = [];

var chance = 3;
var life;
var showscore;
var score = -1;
var a = 1;
var move = 0;
var playercolor = 150;
var stage = 0;