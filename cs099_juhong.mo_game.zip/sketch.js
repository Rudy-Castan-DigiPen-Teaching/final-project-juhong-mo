// Final Project
// Juhong Mo 모주홍
// cs099
// Spring 2020

function setup() {
  createCanvas(1200, 1200);

  MainScene = new MainMenu();
  OptionsScene = new OptionsScreen();
  CreditsScene = new CreditsScreen();
  GameScene = new Game();
  GameoverScene = new GameOverScreen();
  life = new Life();
  showscore = new Score();

  Black();
  Red();
  setInterval(Black, 150);
  setInterval(Red, 8000);

  getScore();
  setInterval(getScore, 150);

  BGM.loop();
}

function preload() {

  BGM = loadSound("bgm.mp3");
  BGM.setVolume(0.3);
  HEART = loadImage("heart.png");

}

function draw() {
  background('Pink');

  Current();
}