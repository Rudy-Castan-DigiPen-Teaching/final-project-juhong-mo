Media

BGM : https://www.youtube.com/user/NoCopyrightSounds
	**NCS: Music Without Limitations
	Our Spotify Playlist → http://spoti.fi/NCS
	Free Download / Stream: http://ncs.io/GetUp **

heart image : self drew picture.