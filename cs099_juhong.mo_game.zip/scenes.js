function DrawTitle(label) {

  push();
  textAlign(CENTER);
  textSize(80);
  fill(0);
  noStroke();
  text(label, width / 2, 250);
  pop();

}

function Current() {

  switch (CurrentScene) {
    case MAIN_MENU:
      MainScene.update();
      MainScene.draw();
      break;
    case OPTIONS_SCREEN:
      OptionsScene.update();
      OptionsScene.draw();
      break;
    case CREDITS_SCREEN:
      CreditsScene.update();
      CreditsScene.draw();
      break;
    case GAME:
      GameScene.update();
      GameScene.draw();
      break;
    case GAME_OVER:
  }

}